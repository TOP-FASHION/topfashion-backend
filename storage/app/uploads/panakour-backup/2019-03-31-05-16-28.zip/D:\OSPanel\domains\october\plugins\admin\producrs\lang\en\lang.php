<?php return [
    'plugin' => [
        'name' => 'Producrs',
        'description' => ''
    ]
];