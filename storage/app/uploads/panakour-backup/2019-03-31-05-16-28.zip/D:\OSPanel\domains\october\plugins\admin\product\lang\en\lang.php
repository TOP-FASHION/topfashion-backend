<?php return [
    'plugin' => [
        'name' => 'product',
        'description' => ''
    ]
];